module("Web Sockets");

test("check Web Sockets support", function() {
  ok(WebSocket, "this browser support Web Sockets");
});
